Download or see the full example at
https://github.com/rdksl/Bidirectional-Utils.cycle-for-Framer


INSTALL:
1. Copy ›Utilscycle.coffee‹ to your prototype’s ›modules‹ folder
2. Call ›Utilscycle = require "Utilscycle”‹ in your prototype.

USE:
Use as the Framer’s default Utils.cycle()

pioneer = Utils.cycle(array) # Set the cycler for an array
pioneer() # Go forward
pioneer() # Go forward
pioneer() # Go forward
pioneer(-1) # Go back


Give no or positive parameter to pioneer() to move to the next item.
Give pioneer() a negative parameter to move to the previous item.